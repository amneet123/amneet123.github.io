<?php

namespace Stripe;

class Card extends ExternalAccount
{

}
